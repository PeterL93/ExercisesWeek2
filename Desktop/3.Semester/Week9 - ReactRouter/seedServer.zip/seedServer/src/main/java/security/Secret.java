
package security;

public class Secret {
  public static byte[] SHARED_SECRET;  
}
