package test;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author lam
 */
public class plainDemoTest {
  
  public plainDemoTest() {
  }
  
  @BeforeClass
  public static void setUpClass() {
  }
  
  @Before
  public void setUp() {
  }
  
  @Test
  public void dummyTest(){
    assertTrue(true);  //Really "nothing" to test in the initial version of the seed
  }
  
}
